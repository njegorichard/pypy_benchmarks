/* CommCenter front-end development script.
 * Set AUTH_ENDPOINT to your approved backend route when integrating.
 * Never validate or store real passwords in browser-side JavaScript.
 */
const COMM_CENTER_CONFIG = {
  AUTH_ENDPOINT: "", // Example: "/api/auth/commcenter/login"
  PASSWORD_RESET_URL: "", // Set to your approved password-reset route.
  SUPPORT_EMAIL: "commcenter-support@absa.africa"
};

const form = document.getElementById("loginForm");
const usernameField = document.getElementById("username");
const passwordField = document.getElementById("password");
const status = document.getElementById("formStatus");
const toggle = document.getElementById("passwordToggle");

function showStatus(message, isError = true) {
  status.textContent = message;
  status.style.color = isError ? "#b00020" : "#174c2c";
}

toggle.addEventListener("click", () => {
  const showing = passwordField.type === "text";
  passwordField.type = showing ? "password" : "text";
  toggle.setAttribute("aria-label", showing ? "Show password" : "Hide password");
  toggle.setAttribute("aria-pressed", String(!showing));
  passwordField.focus();
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  status.textContent = "";
  const username = usernameField.value.trim();
  const password = passwordField.value;
  if (!username || !password) {
    showStatus("Enter your username and password.");
    (!username ? usernameField : passwordField).focus();
    return;
  }

  if (!COMM_CENTER_CONFIG.AUTH_ENDPOINT) {
    showStatus("Front end is ready. Connect the approved authentication API to enable sign-in.", false);
    return;
  }

  const submitButton = form.querySelector(".login-button");
  submitButton.disabled = true;
  try {
    const response = await fetch(COMM_CENTER_CONFIG.AUTH_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify({ username, password })
    });
    if (!response.ok) throw new Error("Sign-in failed. Check your details or contact support.");
    const result = await response.json().catch(() => ({}));
    if (result.redirectUrl) window.location.assign(result.redirectUrl);
    else showStatus(result.message || "Sign-in request completed.", false);
  } catch (error) {
    showStatus(error.message || "Unable to sign in. Please try again.");
  } finally {
    submitButton.disabled = false;
  }
});

document.getElementById("forgotPassword").addEventListener("click", () => {
  if (COMM_CENTER_CONFIG.PASSWORD_RESET_URL) {
    window.location.assign(COMM_CENTER_CONFIG.PASSWORD_RESET_URL);
  } else {
    showStatus("Connect your approved password-reset URL in app.js.", false);
  }
});

document.getElementById("contactSupport").addEventListener("click", (event) => {
  if (!COMM_CENTER_CONFIG.SUPPORT_EMAIL) {
    event.preventDefault();
    showStatus("Set the support email address in app.js.", false);
  }
});
