COMM CENTER — EXACT APPROVED DESIGN + INTERACTIVE FRONT END

The supplied approved artwork is used unchanged as the visual layer:
  assets/commcenter-approved-login.png
Live HTML controls are positioned over the username, password, login,
forgot-password and contact-support areas. The artwork itself is not edited.

FILES
- index.html: page structure and accessible live form controls
- styles.css: responsive positioning and visual interaction states
- app.js: password visibility, validation, reset/support actions and API hook
- assets/commcenter-approved-login.png: exact approved design image

RUN LOCALLY
Open index.html in a browser, or serve this directory using a local web server.
For example, from this directory run: npx http-server .

FRONT-END DEVELOPMENT
- Username and password are real editable fields.
- Password visibility toggle is active.
- Login button validates required fields.
- Forgot Password and Contact Support are wired for configuration.
- The login request is ready to connect to a backend endpoint.

CONNECT AUTHENTICATION
In app.js, set COMM_CENTER_CONFIG.AUTH_ENDPOINT to your approved backend route.
The example request sends JSON { username, password } using POST and
same-origin credentials. Adapt the request/response contract to your API.
The expected optional JSON response fields are message and redirectUrl.
Set PASSWORD_RESET_URL and SUPPORT_EMAIL to your approved destinations.

SECURITY NOTES
This is a front-end development starter, not a complete authentication system.
Do not put credentials, API keys, client secrets or password verification in
app.js. Authenticate on the server over HTTPS; use your organisation's approved
SSO/MFA, CSRF protection, rate limiting, session cookie settings, audit logging
and error handling. Do not log passwords. The demo mode does not send or store
credentials and does not authenticate users.
