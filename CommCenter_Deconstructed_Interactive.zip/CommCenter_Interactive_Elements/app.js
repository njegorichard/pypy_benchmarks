/* CommCenter login UI. Connect this form to an approved server-side authentication endpoint. */
const form = document.getElementById('loginForm');
const username = document.getElementById('username');
const password = document.getElementById('password');
const togglePassword = document.getElementById('togglePassword');
const message = document.getElementById('formMessage');

// Set this to your approved backend route, e.g. '/api/auth/login'.
const AUTH_ENDPOINT = '';

function showMessage(text, type = 'error') {
  message.textContent = text;
  message.className = `form-message ${type}`;
}

togglePassword.addEventListener('click', () => {
  const reveal = password.type === 'password';
  password.type = reveal ? 'text' : 'password';
  togglePassword.classList.toggle('is-visible', reveal);
  togglePassword.setAttribute('aria-label', reveal ? 'Hide password' : 'Show password');
});

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const user = username.value.trim();
  const pass = password.value;
  if (!user || !pass) {
    showMessage('Please enter both your username and password.');
    (!user ? username : password).focus();
    return;
  }

  if (!AUTH_ENDPOINT) {
    showMessage('The interface is working. Connect AUTH_ENDPOINT to your approved authentication service.', 'success');
    return;
  }

  const submitButton = form.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  submitButton.textContent = 'Signing in…';
  showMessage('');
  try {
    const response = await fetch(AUTH_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ username: user, password: pass })
    });
    if (!response.ok) throw new Error('Sign-in failed. Check your details or contact support.');
    showMessage('Sign-in request completed successfully.', 'success');
  } catch (error) {
    showMessage(error.message || 'Unable to sign in. Please try again.');
  } finally {
    submitButton.disabled = false;
    submitButton.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 3h6v18h-6M10 7l5 5-5 5M15 12H3"/></svg>Login';
  }
});

document.getElementById('forgotLink').addEventListener('click', (event) => {
  event.preventDefault();
  showMessage('Password recovery must be connected to your organisation’s approved identity service.');
});
