COMMCenter LOGIN - INTERACTIVE FRONT-END SOURCE

This package rebuilds the approved CommCenter login concept as individual HTML and CSS elements. The full approved screenshot is NOT used as a page background. The approved call-centre agent image is retained as a separate photograph; the logo, headline, channel chips, login card, fields, icons, controls, footer wave and security message are separate editable elements.

FILES
- index.html                         Page structure and editable content
- styles.css                         Layout, responsive styling and visual design
- app.js                              Password toggle, form validation and API integration point
- assets/approved-call-centre-agent.png  Approved agent photograph, separate asset

RUN LOCALLY
1. Extract the ZIP.
2. Open the folder in Visual Studio Code.
3. Start a local static server (for example, the VS Code Live Server extension) and open index.html.
   You can also run: npx http-server .

INTERACTIONS
- Username and password fields accept input.
- Show/hide password control works.
- Login validates required fields.
- Forgot Password displays a setup message until connected to your identity service.
- Contact Support opens the configured support email link.
- The form has an AUTH_ENDPOINT setting in app.js for your approved backend route.

SECURITY / BACKEND INTEGRATION
This is a front-end development prototype, not a production authentication system. Do not store passwords, API secrets, tokens, or credentials in browser JavaScript. Authentication must be performed by a trusted server or approved Absa SSO/identity provider over HTTPS. Configure server-side validation, CSRF protection where applicable, secure HttpOnly cookies, rate limiting, audit logging and the organisation's approved session controls. Update the Contact Support email to the official address before deployment.
