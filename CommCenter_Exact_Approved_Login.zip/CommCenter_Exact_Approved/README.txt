COMM CENTER — EXACT APPROVED LOGIN DESIGN

This package uses the exact approved login artwork supplied in the conversation.
The artwork is included unchanged at:
  assets/commcenter-approved-login.png

FILES
- index.html: page markup
- styles.css: responsive image presentation
- app.js: small placeholder script
- assets/commcenter-approved-login.png: exact approved login artwork

RUN LOCALLY
Open index.html in a modern browser, or serve this folder from your web server.

IMPORTANT
This is an exact visual presentation of the approved design. The username and
password controls shown in the artwork are part of the image, not live HTML form
fields. No credentials are collected or transmitted. To make sign-in functional,
replace the image-based presentation with accessible form controls and connect
those controls to your organisation's approved server-side authentication flow.
Do not put passwords, API keys, or authentication secrets in app.js.
