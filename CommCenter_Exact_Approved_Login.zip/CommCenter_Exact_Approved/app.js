// This package preserves the approved login artwork exactly as provided.
// Authentication is intentionally not simulated or handled in browser code.
