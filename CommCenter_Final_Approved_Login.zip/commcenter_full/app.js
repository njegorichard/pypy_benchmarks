const password = document.getElementById('password');
const toggle = document.getElementById('togglePassword');

toggle?.addEventListener('click', () => {
  const show = password.type === 'password';
  password.type = show ? 'text' : 'password';
  toggle.classList.toggle('visible', show);
  toggle.setAttribute('aria-pressed', String(show));
  toggle.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
});

const year = document.getElementById('year');
if (year) year.textContent = new Date().getFullYear();
