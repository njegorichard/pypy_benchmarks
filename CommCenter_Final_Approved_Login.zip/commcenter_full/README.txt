COMMCenter LOGIN UI — FINAL APPROVED VERSION

Included:
- index.html: responsive CommCenter login page structure and form
- styles.css: responsive styling for desktop, tablet and mobile
- app.js: password visibility toggle and automatic copyright year
- assets/commcenter-call-centre-hero.png: approved call-centre hero image crop

Run locally:
Open index.html in a browser, or serve this folder using your development server.

ASP.NET Core integration:
1. Move the page markup into your Login.cshtml Razor view.
2. Move styles.css and app.js into wwwroot/css and wwwroot/js, updating their references as needed.
3. Move the hero image into wwwroot/assets and adjust the CSS URL if needed.
4. Update /Account/Login, /Account/ForgotPassword and /Support to your application's actual routes.
5. Add @Html.AntiForgeryToken() inside the form when using MVC/Razor.
6. Match the username and password input name attributes to your login view model.

Important:
The form action is a placeholder. This front-end package does not implement authentication. Server-side authentication, validation, anti-forgery validation and secure session handling must be implemented by your application.
